// Arithmetic expression examples from Lecture 2

class Expressions {
  public static void main(String[] args) {
    int x = 1 + 2 * 3;
    System.out.println("x=" + x);

    x = 22 % 7;
    System.out.println("x=" + x);
  }
}
