// Example of a for loop - what will this print?

class ForLoop {
  public static void main(String[] args) {

    int sum = 1;
    for (int n = 0; n < 10; n += 2) {
      sum += n;
    }

    System.out.println(sum);
  }
}
