// Computing a square root in C

#include <math.h>
#include <stdio.h>

int main() {
  double root2 = sqrt(2.0);
  printf("Square root of 2 = %f\n", root2);
  return 0;
}
