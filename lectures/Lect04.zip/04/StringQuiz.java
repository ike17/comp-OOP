// What does this print?

public class StringQuiz {
  public static void main(String[] args) {
    String word = "Programming";
    System.out.println(word.toUpperCase().charAt(6));
    System.out.println(word);
  }
}
