// Example of literal text blocks (Java 17 onwards)

public class TextBlock {
  public static void main(String[] args) {
    String verse = """
                   This is the first line
                   This is the second line
                   This is the third line
                   And this is the final line""";

    System.out.println(verse);
  }  
}
