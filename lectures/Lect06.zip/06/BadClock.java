// Don't write classes like this!

public class Clock {
  public int hours;
  public int minutes;
  public int seconds;
}
