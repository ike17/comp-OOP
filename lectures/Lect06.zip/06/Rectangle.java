// Can you spot the beginner's mistake in this class?
// What other things could we change to improve it?

class Rectangle {

  int width;
  int height;

  public void Rectangle(int w, int h) {
    width = w;
    height = h;
  }

  public int getWidth() {
    return width;
  }

  public int getHeight() {
    return height;
  }
}
