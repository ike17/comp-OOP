// Program which doesn't compile, due to a mistake in Rectangle

class RectangleTest {
  public static void main(String[] args) {
    Rectangle r = new Rectangle(12, 5);
  }
}
