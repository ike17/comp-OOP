// Examples of Unicode escape sequences

class Unicode {
  public static void main(String[] args) {
    System.out.println("A right angle is 90\u00b0");
    System.out.println("This newspaper costs \u20ac1.20");
    System.out.println("Your hand of cards is J\u2665 4\u2666");
  }
}
