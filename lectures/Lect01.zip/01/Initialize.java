/*
   Demonstration that initialisation of variables is enforced in Java.

   (Compare with Initialize.c)
*/

class Initialize {
  public static void main(String[] args) {
    int x;
    System.out.println(x);   // nope!
  }
}
