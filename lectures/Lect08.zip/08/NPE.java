// Example of code that triggers a NullPointerException

class NPE {
  public static void main(String[] args) {
    String s = null;
    System.out.println(s.length());
  }
}
